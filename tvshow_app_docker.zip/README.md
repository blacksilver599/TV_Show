# TV Show App with Docker

## Run with Docker Compose
```bash
docker-compose up --build
```
Frontend: http://localhost:8080  
Backend: http://localhost:4000
```