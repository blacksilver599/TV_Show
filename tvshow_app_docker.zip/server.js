import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(bodyParser.json());

let entries = [];

app.get('/api/entries', (req,res)=>{
  res.json(entries);
});

app.post('/api/entries', (req,res)=>{
  const e = { id: Date.now().toString(), ...req.body, approved: false };
  entries.push(e);
  res.status(201).json(e);
});

app.listen(4000, ()=> console.log('Server running on http://localhost:4000'));
